WITH outer_loop AS (
   SELECT CONCAT(projectid, '.', 
      versionid, '.', epoch) rowid, 
      name, val
   FROM log_records 
   WHERE loglevel = 'o')
CREATE VIEW outer_loop_pivot AS
SELECT * FROM crosstab(
   (SELECT * FROM outer_loop
      ORDER BY rowid, name),
   (SELECT DISTINCT name 
      FROM outer_loop));