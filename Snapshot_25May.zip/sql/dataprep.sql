WITH data_prep AS (
   SELECT CONCAT(projectid, '.',
      versionid) rowid, name, val
   FROM log_records 
   WHERE loglevel = 'd')
CREATE VIEW data_prep_pivot AS
SELECT * FROM crosstab(
   (SELECT * FROM data_prep
      ORDER BY rowid, name),
   (SELECT DISTINCT name 
      FROM data_prep));