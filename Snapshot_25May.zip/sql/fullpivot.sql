CREATE VIEW full_pivot AS
SELECT * FROM data_prep_pivot
   FULL JOIN outer_loop_pivot 
      USING (projectid, versionid)
   FULL JOIN inner_loop_pivot
      USING (projectid, versionid, epoch)
ORDER BY projectid, versionid, epoch, step;