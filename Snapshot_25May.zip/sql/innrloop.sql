WITH inner_loop AS (
   SELECT CONCAT(projectid, '.', 
      versionid, '.', epoch, '.',
      step) rowid, name, val
   FROM log_records 
   WHERE loglevel = 'i')
CREATE VIEW inner_loop_pivot AS
SELECT * FROM crosstab(
   (SELECT * FROM inner_loop
      ORDER BY rowid, name),
   (SELECT DISTINCT name 
      FROM inner_loop));